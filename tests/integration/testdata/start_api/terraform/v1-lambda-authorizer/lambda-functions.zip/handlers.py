import json

def auth_handler(event, context):
    return {
        "principalId": "user|a1b2c3d4",
        "policyDocument": {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Action": "execute-api:Invoke",
                    "Effect": "Allow",
                    "Resource": [
                        "arn:aws:execute-api:us-east-1:123456789012:1234567890/None/*/*"
                    ]
                }
            ]
        },
        "context":{
            "message": "from authorizer"
        }
    }

def hello_handler(event, context):
    message = event.get("requestContext", {}).get("authorizer", {}).get("message")

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": message
        })
    }