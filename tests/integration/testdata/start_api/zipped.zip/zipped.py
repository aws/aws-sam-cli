import time
import json
def sleep_10_sec_handler(event, context):
    # sleep thread for 10s. This is useful for testing multiple requests
    time.sleep(10)

    return {"statusCode": 200, "body": json.dumps({"message": "HelloWorld! I just slept and waking up."})}
