import json
import lib
import lib2


def lambda_handler(event, context):
    const_value = lib.get_const() + lib2.get_const()
    return {
        "statusCode": 200,
        "body": f"hello world {const_value}",
    }
