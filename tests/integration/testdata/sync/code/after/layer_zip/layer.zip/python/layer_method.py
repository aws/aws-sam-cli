def layer_method():
    return 50