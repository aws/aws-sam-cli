def layer_method():
    return 20