def get_const():
    return 5