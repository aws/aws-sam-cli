import json
import lib

# import requests


def lambda_handler(event, context):
    const_value = lib.get_const()
    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": f"hello world {const_value}",
            # "location": ip.text.replace("\n", "")
        }),
    }
