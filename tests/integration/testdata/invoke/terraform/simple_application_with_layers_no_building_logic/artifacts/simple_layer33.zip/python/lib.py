def get_const():
    return 33