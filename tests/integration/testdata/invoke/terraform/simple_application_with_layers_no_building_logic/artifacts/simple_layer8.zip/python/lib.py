def get_const():
    return 8