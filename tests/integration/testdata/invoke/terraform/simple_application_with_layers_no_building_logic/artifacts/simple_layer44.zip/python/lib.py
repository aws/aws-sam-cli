def get_const():
    return 44