def farewell():
    return "goodbye from layer B"
