def greeting():
    return "hello from layer A"
